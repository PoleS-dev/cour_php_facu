

<?php
 final class Voiture extends Vehicules
{

    public const CATEGORIE = "Voiture";

}




